import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getSession } from "@/lib/auth"

export async function POST() {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const subscriptions = await sql`
      SELECT * FROM subscriptions 
      WHERE user_id = ${session.userId} AND status = 'active'
      ORDER BY created_at DESC
      LIMIT 1
    `

    if (subscriptions.length === 0) {
      return NextResponse.json({ error: "No active subscription found" }, { status: 400 })
    }

    const subscription = subscriptions[0]

    // Check if within refund window
    if (!subscription.refund_eligible_until || new Date(subscription.refund_eligible_until) <= new Date()) {
      return NextResponse.json({ error: "Refund period has expired" }, { status: 400 })
    }

    // TODO: Process refund via Lemon Squeezy API
    // For now, just mark as refunded
    console.log(
      `[FixOps] Processing refund for subscription ${subscription.id}, transaction: ${subscription.transaction_id}`,
    )

    await sql`
      UPDATE subscriptions 
      SET status = 'refunded'
      WHERE id = ${subscription.id}
    `

    return NextResponse.json({ success: true, message: "Refund request submitted" })
  } catch (error) {
    console.error("Refund request error:", error)
    return NextResponse.json({ error: "Failed to process refund" }, { status: 500 })
  }
}
