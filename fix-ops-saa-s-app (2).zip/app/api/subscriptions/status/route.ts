import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getSession } from "@/lib/auth"

export async function GET() {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const subscriptions = await sql`
      SELECT * FROM subscriptions 
      WHERE user_id = ${session.userId}
      ORDER BY created_at DESC
      LIMIT 1
    `

    if (subscriptions.length === 0) {
      return NextResponse.json({
        subscription: null,
        isRefundEligible: false,
      })
    }

    const subscription = subscriptions[0]
    const isRefundEligible =
      subscription.refund_eligible_until && new Date(subscription.refund_eligible_until) > new Date()

    return NextResponse.json({
      subscription,
      isRefundEligible,
    })
  } catch (error) {
    console.error("Subscription status error:", error)
    return NextResponse.json({ error: "Failed to fetch subscription" }, { status: 500 })
  }
}
