import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const { name, email, phone, subject, message } = await request.json()

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json({ error: "Name, email, subject, and message are required" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    // Save to database
    await sql`
      INSERT INTO contacts (name, email, phone, subject, message, status)
      VALUES (${name}, ${email}, ${phone || null}, ${subject}, ${message}, 'new')
    `

    // TODO: Send email notification to support@fixops.com
    console.log(`[FixOps] New contact form submission from ${name} (${email}) - Subject: ${subject}`)

    return NextResponse.json({ success: true, message: "Your message has been sent successfully!" })
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json({ error: "Failed to submit contact form" }, { status: 500 })
  }
}
