import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getSession } from "@/lib/auth"

export async function GET() {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Get total jobs
    const totalResult = await sql`SELECT COUNT(*) as count FROM jobs WHERE user_id = ${session.userId}`
    const total = Number(totalResult[0]?.count) || 0

    // Get completed this month
    const completedResult = await sql`
      SELECT COUNT(*) as count FROM jobs 
      WHERE user_id = ${session.userId} 
      AND status = 'completed'
      AND DATE_TRUNC('month', created_at) = DATE_TRUNC('month', CURRENT_DATE)
    `
    const completedThisMonth = Number(completedResult[0]?.count) || 0

    // Get pending (scheduled + in_progress)
    const pendingResult = await sql`
      SELECT COUNT(*) as count FROM jobs 
      WHERE user_id = ${session.userId} 
      AND status IN ('scheduled', 'in_progress')
    `
    const pending = Number(pendingResult[0]?.count) || 0

    // Calculate estimated revenue (completed jobs * average job value)
    const revenue = completedThisMonth * 150 // Placeholder average job value

    return NextResponse.json({
      stats: {
        total,
        completedThisMonth,
        pending,
        revenue,
      },
    })
  } catch (error) {
    console.error("Stats error:", error)
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}
