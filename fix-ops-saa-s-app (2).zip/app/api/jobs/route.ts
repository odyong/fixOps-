import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getSession } from "@/lib/auth"

export async function GET(request: Request) {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const status = searchParams.get("status")

  let jobs
  if (status && status !== "all") {
    jobs = await sql`
      SELECT * FROM jobs 
      WHERE user_id = ${session.userId} AND status = ${status}
      ORDER BY scheduled_date DESC
    `
  } else {
    jobs = await sql`
      SELECT * FROM jobs 
      WHERE user_id = ${session.userId}
      ORDER BY scheduled_date DESC
    `
  }

  return NextResponse.json({ jobs })
}

export async function POST(request: Request) {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { title, description, customer_name, customer_email, customer_phone, scheduled_date, status } = body

    if (!title || !customer_name || !scheduled_date) {
      return NextResponse.json({ error: "Title, customer name, and scheduled date are required" }, { status: 400 })
    }

    const jobs = await sql`
      INSERT INTO jobs (user_id, title, description, customer_name, customer_email, customer_phone, scheduled_date, status)
      VALUES (${session.userId}, ${title}, ${description || null}, ${customer_name}, ${customer_email || null}, ${customer_phone || null}, ${scheduled_date}, ${status || "scheduled"})
      RETURNING *
    `

    return NextResponse.json({ job: jobs[0] })
  } catch (error) {
    console.error("Create job error:", error)
    return NextResponse.json({ error: "Failed to create job" }, { status: 500 })
  }
}
