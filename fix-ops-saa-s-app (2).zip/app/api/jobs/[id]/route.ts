import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getSession } from "@/lib/auth"

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { id } = await params

  try {
    const body = await request.json()
    const { title, description, customer_name, customer_email, customer_phone, scheduled_date, status } = body

    // Verify job belongs to user
    const existing = await sql`SELECT id FROM jobs WHERE id = ${id} AND user_id = ${session.userId}`
    if (existing.length === 0) {
      return NextResponse.json({ error: "Job not found" }, { status: 404 })
    }

    const jobs = await sql`
      UPDATE jobs 
      SET title = ${title}, description = ${description || null}, customer_name = ${customer_name}, 
          customer_email = ${customer_email || null}, customer_phone = ${customer_phone || null}, 
          scheduled_date = ${scheduled_date}, status = ${status}
      WHERE id = ${id} AND user_id = ${session.userId}
      RETURNING *
    `

    return NextResponse.json({ job: jobs[0] })
  } catch (error) {
    console.error("Update job error:", error)
    return NextResponse.json({ error: "Failed to update job" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { id } = await params

  try {
    // Verify job belongs to user
    const existing = await sql`SELECT id FROM jobs WHERE id = ${id} AND user_id = ${session.userId}`
    if (existing.length === 0) {
      return NextResponse.json({ error: "Job not found" }, { status: 404 })
    }

    await sql`DELETE FROM jobs WHERE id = ${id} AND user_id = ${session.userId}`

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete job error:", error)
    return NextResponse.json({ error: "Failed to delete job" }, { status: 500 })
  }
}
