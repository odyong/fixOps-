import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { getSession } from "@/lib/auth"

export async function GET() {
  const session = await getSession()
  if (!session || session.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
  }

  try {
    // Total users
    const usersResult = await sql`SELECT COUNT(*) as count FROM users`
    const totalUsers = Number(usersResult[0]?.count) || 0

    // Active subscriptions
    const activeResult = await sql`SELECT COUNT(*) as count FROM subscriptions WHERE status = 'active'`
    const activeSubscriptions = Number(activeResult[0]?.count) || 0

    // MRR (Monthly Recurring Revenue)
    const mrrResult = await sql`
      SELECT COALESCE(SUM(
        CASE 
          WHEN plan_type = 'yearly' THEN amount / 12
          ELSE amount
        END
      ), 0) as mrr 
      FROM subscriptions 
      WHERE status = 'active'
    `
    const mrr = Number(mrrResult[0]?.mrr) || 0

    // Total revenue
    const revenueResult = await sql`
      SELECT COALESCE(SUM(amount), 0) as total 
      FROM subscriptions 
      WHERE status IN ('active', 'canceled')
    `
    const totalRevenue = Number(revenueResult[0]?.total) || 0

    return NextResponse.json({
      stats: {
        totalUsers,
        activeSubscriptions,
        mrr,
        totalRevenue,
      },
    })
  } catch (error) {
    console.error("Admin stats error:", error)
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}
