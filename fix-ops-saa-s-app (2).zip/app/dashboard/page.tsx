"use client"

import { useState, useEffect, useCallback } from "react"
import { Plus } from "lucide-react"
import useSWR from "swr"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { JobsTable } from "@/components/dashboard/jobs-table"
import { JobDialog } from "@/components/dashboard/job-dialog"
import { SubscriptionBadge } from "@/components/dashboard/subscription-badge"
import { Button } from "@/components/ui/button"
import type { Job } from "@/lib/db"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [statusFilter, setStatusFilter] = useState("all")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingJob, setEditingJob] = useState<Job | null>(null)

  const { data: statsData, mutate: mutateStats } = useSWR("/api/jobs/stats", fetcher)
  const { data: jobsData, mutate: mutateJobs } = useSWR(`/api/jobs?status=${statusFilter}`, fetcher)
  const { data: subData, mutate: mutateSub } = useSWR("/api/subscriptions/status", fetcher)

  const stats = statsData?.stats || { total: 0, completedThisMonth: 0, pending: 0, revenue: 0 }
  const jobs = jobsData?.jobs || []
  const subscription = subData?.subscription || null
  const isRefundEligible = subData?.isRefundEligible || false

  const handleSaveJob = useCallback(
    async (data: Partial<Job>) => {
      if (editingJob) {
        await fetch(`/api/jobs/${editingJob.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        })
      } else {
        await fetch("/api/jobs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        })
      }
      mutateJobs()
      mutateStats()
      setEditingJob(null)
    },
    [editingJob, mutateJobs, mutateStats],
  )

  const handleDeleteJob = useCallback(
    async (id: number) => {
      await fetch(`/api/jobs/${id}`, { method: "DELETE" })
      mutateJobs()
      mutateStats()
    },
    [mutateJobs, mutateStats],
  )

  const handleEditJob = useCallback((job: Job) => {
    setEditingJob(job)
    setDialogOpen(true)
  }, [])

  const handleRequestRefund = useCallback(async () => {
    const res = await fetch("/api/subscriptions/request-refund", { method: "POST" })
    if (res.ok) {
      mutateSub()
    }
  }, [mutateSub])

  useEffect(() => {
    if (!dialogOpen) {
      setEditingJob(null)
    }
  }, [dialogOpen])

  return (
    <>
      <DashboardHeader title="Dashboard" onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
      <main className="flex-1 space-y-6 p-4 lg:p-6">
        <SubscriptionBadge
          subscription={subscription}
          isRefundEligible={isRefundEligible}
          onRequestRefund={handleRequestRefund}
        />

        <StatsCards stats={stats} />

        <div className="space-y-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap gap-2">
              {["all", "scheduled", "in_progress", "completed"].map((status) => (
                <Button
                  key={status}
                  variant={statusFilter === status ? "default" : "outline"}
                  size="sm"
                  onClick={() => setStatusFilter(status)}
                  className={statusFilter === status ? "bg-primary text-primary-foreground" : ""}
                >
                  {status === "all"
                    ? "All"
                    : status === "in_progress"
                      ? "In Progress"
                      : status.charAt(0).toUpperCase() + status.slice(1)}
                </Button>
              ))}
            </div>
            <Button onClick={() => setDialogOpen(true)} className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Plus className="mr-2 h-4 w-4" />
              Add New Job
            </Button>
          </div>

          <JobsTable jobs={jobs} onEdit={handleEditJob} onDelete={handleDeleteJob} />
        </div>
      </main>

      <JobDialog open={dialogOpen} onOpenChange={setDialogOpen} job={editingJob} onSave={handleSaveJob} />
    </>
  )
}
