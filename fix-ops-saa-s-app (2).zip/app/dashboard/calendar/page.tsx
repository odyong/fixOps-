import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function CalendarPage() {
  return (
    <>
      <DashboardHeader title="Calendar" />
      <main className="flex-1 p-4 lg:p-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Calendar Integration
                </CardTitle>
                <CardDescription>Sync your jobs with Google Calendar for seamless scheduling.</CardDescription>
              </div>
              <Badge className="bg-accent text-accent-foreground">Coming Soon</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex h-60 flex-col items-center justify-center gap-4 rounded-lg border border-dashed">
              <Clock className="h-12 w-12 text-muted-foreground" />
              <div className="text-center">
                <p className="font-medium">Google Calendar Integration</p>
                <p className="text-sm text-muted-foreground">
                  We&apos;re working on this feature. Stay tuned for updates!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </>
  )
}
