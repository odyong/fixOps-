"use client"

import useSWR from "swr"
import { format } from "date-fns"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

const planLabels: Record<string, string> = {
  launch: "Launch Special",
  monthly: "Monthly",
  yearly: "Annual",
}

const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-800",
  pending_payment: "bg-yellow-100 text-yellow-800",
  canceled: "bg-gray-100 text-gray-800",
  refunded: "bg-red-100 text-red-800",
}

export default function AdminUsersPage() {
  const { data } = useSWR("/api/admin/users", fetcher)
  const users = data?.users || []

  return (
    <main className="flex-1 p-6">
      <Card>
        <CardHeader>
          <CardTitle>Users</CardTitle>
          <CardDescription>Manage all registered users and their subscriptions.</CardDescription>
        </CardHeader>
        <CardContent>
          {users.length === 0 ? (
            <div className="flex h-40 items-center justify-center rounded-lg border border-dashed">
              <p className="text-muted-foreground">No users found.</p>
            </div>
          ) : (
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead>Amount Paid</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map(
                    (user: {
                      id: number
                      name: string
                      email: string
                      plan_type: string
                      subscription_status: string
                      created_at: string
                      amount: number
                    }) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.plan_type ? planLabels[user.plan_type] || user.plan_type : "-"}</TableCell>
                        <TableCell>
                          {user.subscription_status ? (
                            <Badge className={statusColors[user.subscription_status]} variant="secondary">
                              {user.subscription_status.replace("_", " ")}
                            </Badge>
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell>{format(new Date(user.created_at), "MMM d, yyyy")}</TableCell>
                        <TableCell>{user.amount ? `$${user.amount}` : "-"}</TableCell>
                      </TableRow>
                    ),
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}
