"use client"

import useSWR from "swr"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, DollarSign, CreditCard, RefreshCw } from "lucide-react"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export default function AdminRevenuePage() {
  const { data } = useSWR("/api/admin/stats", fetcher)
  const stats = data?.stats || { totalUsers: 0, activeSubscriptions: 0, mrr: 0, totalRevenue: 0 }

  return (
    <main className="flex-1 p-6">
      <h2 className="mb-6 text-2xl font-bold">Revenue Analytics</h2>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-accent" />
              Monthly Recurring Revenue
            </CardTitle>
            <CardDescription>Current MRR from active subscriptions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-accent">${stats.mrr.toLocaleString()}</div>
            <p className="mt-2 text-sm text-muted-foreground">
              Based on {stats.activeSubscriptions} active subscribers
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-green-600" />
              Total Revenue
            </CardTitle>
            <CardDescription>All-time revenue collected</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-green-600">${stats.totalRevenue.toLocaleString()}</div>
            <p className="mt-2 text-sm text-muted-foreground">Including refunded and canceled subscriptions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              Conversion Rate
            </CardTitle>
            <CardDescription>Users who completed payment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-primary">
              {stats.totalUsers > 0 ? ((stats.activeSubscriptions / stats.totalUsers) * 100).toFixed(1) : 0}%
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {stats.activeSubscriptions} of {stats.totalUsers} users
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5 text-blue-600" />
              Average Revenue Per User
            </CardTitle>
            <CardDescription>ARPU for active subscribers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-blue-600">
              ${stats.activeSubscriptions > 0 ? (stats.totalRevenue / stats.activeSubscriptions).toFixed(2) : 0}
            </div>
            <p className="mt-2 text-sm text-muted-foreground">Per paying customer</p>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
