import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "fallback-secret-change-in-production")

const publicPaths = ["/", "/login", "/signup", "/contact", "/privacy", "/terms", "/forgot-password"]
const adminPaths = ["/admin"]

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const token = request.cookies.get("token")?.value

  // Allow public paths
  if (publicPaths.includes(pathname) || pathname.startsWith("/api/auth") || pathname.startsWith("/api/contact")) {
    // If logged in and trying to access login/signup, redirect to dashboard
    if ((pathname === "/login" || pathname === "/signup") && token) {
      try {
        await jwtVerify(token, JWT_SECRET)
        return NextResponse.redirect(new URL("/dashboard", request.url))
      } catch {
        // Token invalid, allow access to login/signup
      }
    }
    return NextResponse.next()
  }

  // Check for valid token on protected routes
  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)

    // Check admin routes
    if (adminPaths.some((path) => pathname.startsWith(path))) {
      if (payload.role !== "admin") {
        return NextResponse.redirect(new URL("/dashboard", request.url))
      }
    }

    return NextResponse.next()
  } catch {
    // Invalid token, redirect to login
    const response = NextResponse.redirect(new URL("/login", request.url))
    response.cookies.delete("token")
    return response
  }
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
}
