import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"
import { sql, type User } from "./db"
import bcrypt from "bcryptjs"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "fallback-secret-change-in-production")

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export async function createToken(userId: number, role: string): Promise<string> {
  return new SignJWT({ userId, role })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(JWT_SECRET)
}

export async function verifyToken(token: string): Promise<{ userId: number; role: string } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload as { userId: number; role: string }
  } catch {
    return null
  }
}

export async function getSession(): Promise<{ userId: number; role: string } | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get("token")?.value
  if (!token) return null
  return verifyToken(token)
}

export async function getCurrentUser(): Promise<Omit<User, "password_hash"> | null> {
  const session = await getSession()
  if (!session) return null

  const users = await sql`
    SELECT id, name, email, role, created_at 
    FROM users 
    WHERE id = ${session.userId}
  `
  return users[0] as Omit<User, "password_hash"> | null
}

export async function logout() {
  const cookieStore = await cookies()
  cookieStore.delete("token")
}
