import { neon } from "@neondatabase/serverless"

export const sql = neon(process.env.DATABASE_URL!)

export type User = {
  id: number
  name: string
  email: string
  password_hash: string
  role: "user" | "admin"
  created_at: string
}

export type Subscription = {
  id: number
  user_id: number
  plan_type: "launch" | "monthly" | "yearly"
  status: "pending_payment" | "active" | "refunded" | "canceled"
  start_date: string | null
  end_date: string | null
  transaction_id: string | null
  amount: number | null
  refund_eligible_until: string | null
  created_at: string
}

export type Job = {
  id: number
  user_id: number
  title: string
  description: string | null
  customer_name: string
  customer_email: string | null
  customer_phone: string | null
  scheduled_date: string
  status: "scheduled" | "in_progress" | "completed"
  created_at: string
}

export type Contact = {
  id: number
  name: string
  email: string
  phone: string | null
  subject: string
  message: string
  status: "new" | "in_progress" | "resolved"
  created_at: string
}
