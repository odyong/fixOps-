import Link from "next/link"
import { Check, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const plans = [
  {
    name: "Launch Special",
    price: "$39",
    period: "first month",
    description: "Then $89/month. Perfect for getting started.",
    features: [
      "Unlimited jobs",
      "Customer management",
      "Invoice generation",
      "Payment processing",
      "Email support",
      "7-day money-back guarantee",
    ],
    cta: "Start Now",
    popular: true,
  },
  {
    name: "Monthly",
    price: "$89",
    period: "per month",
    description: "Full access with monthly flexibility.",
    features: [
      "Unlimited jobs",
      "Customer management",
      "Invoice generation",
      "Payment processing",
      "Priority support",
      "7-day money-back guarantee",
    ],
    cta: "Get Started",
    popular: false,
  },
  {
    name: "Annual",
    price: "$960",
    period: "per year",
    description: "Save $108 compared to monthly billing.",
    features: [
      "Unlimited jobs",
      "Customer management",
      "Invoice generation",
      "Payment processing",
      "Priority support",
      "7-day money-back guarantee",
    ],
    cta: "Get Started",
    popular: false,
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="bg-muted/50 py-20">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">Simple, Transparent Pricing</h2>
          <p className="mt-4 text-muted-foreground">
            Choose the plan that works best for your business. All plans include our full feature set.
          </p>
        </div>

        <div className="mx-auto mt-12 grid max-w-5xl gap-6 md:grid-cols-3">
          {plans.map((plan) => (
            <Card key={plan.name} className={`relative ${plan.popular ? "border-accent shadow-lg" : ""}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground">
                  <Star className="mr-1 h-3 w-3" />
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center">
                <CardTitle>{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>
                <CardDescription className="mt-2">{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-accent" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  asChild
                  className={`w-full ${plan.popular ? "bg-accent text-accent-foreground hover:bg-accent/90" : ""}`}
                  variant={plan.popular ? "default" : "outline"}
                >
                  <Link href="/signup">{plan.cta}</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Refund Policy */}
        <div className="mx-auto mt-12 max-w-2xl">
          <Card className="border-accent/50 bg-accent/5">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-accent/10">
                <Check className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="font-semibold">Risk-Free 7-Day Guarantee</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Try FixOps risk-free for 7 days. If you&apos;re not satisfied, get a full refund - no questions asked.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
