import { Play } from "lucide-react"

export function About() {
  return (
    <section className="bg-muted/50 py-20">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">See FixOps in Action</h2>
          <p className="mt-4 text-muted-foreground">
            Watch how service businesses are saving hours every week with automated scheduling, invoicing, and customer
            management.
          </p>
        </div>

        {/* Video Placeholder */}
        <div className="mx-auto mt-10 max-w-4xl">
          <div className="relative aspect-video overflow-hidden rounded-xl border border-border bg-muted">
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Play className="h-8 w-8 text-primary" />
              </div>
              <p className="text-lg font-medium text-muted-foreground">Video Coming Soon</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
