import { Calendar, CreditCard, Users, Sparkles, FileText, CalendarClock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const features = [
  {
    icon: CalendarClock,
    title: "Job Scheduling & Management",
    description: "Easily schedule, track, and manage all your service jobs from one dashboard.",
  },
  {
    icon: CreditCard,
    title: "Automated Payment Processing",
    description: "Accept payments online and automate invoicing for faster cash flow.",
  },
  {
    icon: Calendar,
    title: "Google Calendar Integration",
    description: "Sync your jobs with Google Calendar for seamless scheduling.",
    badge: "Coming Soon",
  },
  {
    icon: Users,
    title: "Customer Management",
    description: "Keep track of customer information, service history, and preferences.",
  },
  {
    icon: Sparkles,
    title: "AI-Powered Suggestions",
    description: "Get smart recommendations for pricing, scheduling, and customer engagement.",
    badge: "Coming Soon",
  },
  {
    icon: FileText,
    title: "Invoice & Receipt Generation",
    description: "Generate professional invoices and receipts automatically after each job.",
  },
]

export function Features() {
  return (
    <section id="features" className="py-20">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Everything You Need to Run Your Business
          </h2>
          <p className="mt-4 text-muted-foreground">
            Powerful features designed specifically for service professionals.
          </p>
        </div>

        <div className="mx-auto mt-12 grid max-w-5xl gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <Card key={feature.title} className="relative">
              {feature.badge && (
                <Badge className="absolute right-4 top-4 bg-accent text-accent-foreground">{feature.badge}</Badge>
              )}
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="mt-4">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
