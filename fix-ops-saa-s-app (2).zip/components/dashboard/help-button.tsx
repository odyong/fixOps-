"use client"

import Link from "next/link"
import { HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HelpButton() {
  return (
    <Button
      asChild
      className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-accent text-accent-foreground shadow-lg hover:bg-accent/90"
    >
      <Link href="/contact">
        <HelpCircle className="h-6 w-6" />
        <span className="sr-only">Need Help?</span>
      </Link>
    </Button>
  )
}
