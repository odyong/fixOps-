"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Crown, AlertCircle } from "lucide-react"
import type { Subscription } from "@/lib/db"

interface SubscriptionBadgeProps {
  subscription: Subscription | null
  isRefundEligible: boolean
  onRequestRefund: () => void
}

const planLabels = {
  launch: "Launch Special",
  monthly: "Monthly",
  yearly: "Annual",
}

export function SubscriptionBadge({ subscription, isRefundEligible, onRequestRefund }: SubscriptionBadgeProps) {
  if (!subscription) {
    return (
      <Card className="border-yellow-200 bg-yellow-50">
        <CardContent className="flex items-center gap-3 p-4">
          <AlertCircle className="h-5 w-5 text-yellow-600" />
          <div>
            <p className="font-medium text-yellow-800">Payment Required</p>
            <p className="text-sm text-yellow-700">Complete payment to access all features</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (subscription.status === "pending_payment") {
    return (
      <Card className="border-yellow-200 bg-yellow-50">
        <CardContent className="flex items-center gap-3 p-4">
          <AlertCircle className="h-5 w-5 text-yellow-600" />
          <div>
            <p className="font-medium text-yellow-800">Pending Payment</p>
            <p className="text-sm text-yellow-700">Complete your payment to activate your subscription</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10">
            <Crown className="h-5 w-5 text-accent" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="font-medium">{planLabels[subscription.plan_type]}</p>
              <Badge variant={subscription.status === "active" ? "default" : "secondary"}>
                {subscription.status === "active" ? "Active" : subscription.status}
              </Badge>
            </div>
            {isRefundEligible && <p className="text-sm text-muted-foreground">Refund eligible</p>}
          </div>
        </div>
        {isRefundEligible && subscription.status === "active" && (
          <Button variant="outline" size="sm" onClick={onRequestRefund}>
            Request Refund
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
